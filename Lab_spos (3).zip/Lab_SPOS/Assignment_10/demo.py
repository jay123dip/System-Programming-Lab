len_str=int(input("Enter string length: "))
str_com=[]
for i in range(len_str):
    a=int(input(f'Enter the component {i+1}: '))
    str_com.append(a)
frame_size=int(input("Enter frame size: "))
miss=0
frame_arr=[0]*frame_size
j=0
for i in range(len_str):
    if(str_com[i] not in frame_arr):
        miss+=1
        if(j<frame_size):
            frame_arr[j]=str_com[i]
            j+=1
        else:
            m=frame_size-1
            while(m>=0):
                if(frame_arr[m] not in str_com[i:len_str]):
                    frame_arr[m]=str_com[i]
                else:
                    m-=1
print(f'Total Page fault {miss}.')
print(f'Total page hit {len_str-miss}.')
print(f'Page fault ratio {miss}/{len_str}')            
