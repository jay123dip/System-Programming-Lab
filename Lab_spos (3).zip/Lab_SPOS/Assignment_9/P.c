#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>

void main()
{
    int ch;
    while(1)
    {
        printf("1.Running Processes \n 2.Join Processes \n 3.Create processes \n Enter your choice:");
        scanf("%d",&ch);
        switch (ch)
        {
        case 1:
            system("ps");
            break;

        case 2:
            system("join text1.txt text2.txt > text3.txt");
            break;
        
        case 3: 
            {
                int pid;
                pid=fork();
                if(pid==0)
                {
                    sleep(2); 
                    printf("child process\n");
                    execl("/bin/ps","/bin/ps","NULL");
                }
                else
                {
                    printf("Parent Process\n");
                    wait();
                }
            }
            break;
        default:
            break;
        }

    }
}