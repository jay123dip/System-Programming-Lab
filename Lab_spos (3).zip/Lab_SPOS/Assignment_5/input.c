#include<iostream.h>
void main()
{

//Declaration
int a,b

a=3;
b=4;
 
/* here we are adding the values of a and b the c by using + operator */

c=a+b

}
